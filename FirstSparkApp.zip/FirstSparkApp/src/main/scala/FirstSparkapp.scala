import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf

object FirstSparkapp {
  def main(args: Array[String]) {
    val conf = new SparkConf().setAppName("FirstSparkproject").setMaster("local")
    val sc = new SparkContext(conf)
        println("########################")  
        println("First spark project")
        println("########################")    
  }
}
